These files are from the libpng library - http://www.libpng.org/

We have removed all `extern "C"` from the library to prevent symbol collision
with projects that use their own version of libpng.
